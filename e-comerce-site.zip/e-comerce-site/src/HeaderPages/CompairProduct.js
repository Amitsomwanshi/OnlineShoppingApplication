import React from "react";
import "./CompairProduct.css";
import Header from "../componants/Header";
import Footer from "../componants/Footer";
import Bradecrum from "../componants/Bradecrum";

export default function CompairProduct() {
  return (
    <div>
      <Header />
      <Bradecrum />
      <div className="compare-product-wrapper py-5 home-wrapper-2">
        <div className="container-xxl">
          <div className="row">
            <div className="col-3">
              <div className="compare-product-card position-reletive">
                <img src="images/cross.svg" className="cross" alt="" />
                <div className="product-card-image">
                  <img src="images/honartab3.jpg" alt=""></img>
                </div>
                <div className="compare-product-details">
                  <h5 className="title">
                    <b>
                      Honor T1 7.0 1 GB RAM 8 GB ROM 7 Inch with wi Fi+3g Tablet
                    </b>
                  </h5>
                  <h6 className="price mb-3 mt-3">$ 100.00</h6>

                  <div>
                    <div className="product-detail">
                      <h5>
                        <b>Brand :</b>
                      </h5>
                      <p>Havels</p>
                    </div>
                    <div className="product-detail">
                      <h5>
                        <b>Type : </b>
                      </h5>
                      <p>Tablet Computer</p>
                    </div>
                    <div className="product-detail">
                      <h5>
                        <b>Availablity :</b>
                      </h5>
                      <p>In Stack</p>
                    </div>
                    <div className="product-detail">
                      <h5>
                        <b>Color :</b>
                      </h5>
                      <ul className="colors ps-0">
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                      </ul>
                    </div>
                    <div className="product-detail">
                      <h5>
                        <b> Size :</b>
                      </h5>
                      <div className="d-flex gap-10">
                        <p>S</p>
                        <p>M</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-3">
              <div className="compare-product-card position-reletive">
                <img src="images/cross.svg" className="cross" alt="" />
                <div className="product-card-image">
                  <img src="images/honartab3.jpg" alt=""></img>
                </div>
                <div className="compare-product-details">
                  <h5 className="title">
                    <b>
                      Honor T1 7.0 1 GB RAM 8 GB ROM 7 Inch with wi Fi+3g Tablet
                    </b>
                  </h5>
                  <h6 className="price mb-3 mt-3">$ 100.00</h6>

                  <div>
                    <div className="product-detail">
                      <h5>
                        <b>Brand :</b>
                      </h5>
                      <p>Havels</p>
                    </div>
                    <div className="product-detail">
                      <h5>
                        <b>Type : </b>
                      </h5>
                      <p>Tablet Computer</p>
                    </div>
                    <div className="product-detail">
                      <h5>
                        <b>Availablity :</b>
                      </h5>
                      <p>In Stack</p>
                    </div>
                    <div className="product-detail">
                      <h5>
                        <b>Color :</b>
                      </h5>
                      <ul className="colors ps-0">
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                      </ul>
                    </div>
                    <div className="product-detail">
                      <h5>
                        <b> Size :</b>
                      </h5>
                      <div className="d-flex gap-10">
                        <p>S</p>
                        <p>M</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-3">
              <div className="compare-product-card position-reletive">
                <img src="images/cross.svg" className="cross" alt="" />
                <div className="product-card-image">
                  <img src="images/honartab3.jpg" alt=""></img>
                </div>
                <div className="compare-product-details">
                  <h5 className="title">
                    <b>
                      Honor T1 7.0 1 GB RAM 8 GB ROM 7 Inch with wi Fi+3g Tablet
                    </b>
                  </h5>
                  <h6 className="price mb-3 mt-3">$ 100.00</h6>

                  <div>
                    <div className="product-detail">
                      <h5>
                        <b>Brand :</b>
                      </h5>
                      <p>Havels</p>
                    </div>
                    <div className="product-detail">
                      <h5>
                        <b>Type : </b>
                      </h5>
                      <p>Tablet Computer</p>
                    </div>
                    <div className="product-detail">
                      <h5>
                        <b>Availablity :</b>
                      </h5>
                      <p>In Stack</p>
                    </div>
                    <div className="product-detail">
                      <h5>
                        <b>Color :</b>
                      </h5>
                      <ul className="colors ps-0">
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                      </ul>
                    </div>
                    <div className="product-detail">
                      <h5>
                        <b> Size :</b>
                      </h5>
                      <div className="d-flex gap-10">
                        <p>S</p>
                        <p>M</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-3">
              <div className="compare-product-card position-reletive">
                <img src="images/cross.svg" className="cross" alt="" />
                <div className="product-card-image">
                  <img src="images/honartab3.jpg" alt=""></img>
                </div>
                <div className="compare-product-details">
                  <h5 className="title">
                    <b>
                      Honor T1 7.0 1 GB RAM 8 GB ROM 7 Inch with wi Fi+3g Tablet
                    </b>
                  </h5>
                  <h6 className="price mb-3 mt-3">$ 100.00</h6>

                  <div>
                    <div className="product-detail">
                      <h5>
                        <b>Brand :</b>
                      </h5>
                      <p>Havels</p>
                    </div>
                    <div className="product-detail">
                      <h5>
                        <b>Type : </b>
                      </h5>
                      <p>Tablet Computer</p>
                    </div>
                    <div className="product-detail">
                      <h5>
                        <b>Availablity :</b>
                      </h5>
                      <p>In Stack</p>
                    </div>
                    <div className="product-detail">
                      <h5>
                        <b>Color :</b>
                      </h5>
                      <ul className="colors ps-0">
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                      </ul>
                    </div>
                    <div className="product-detail">
                      <h5>
                        <b> Size :</b>
                      </h5>
                      <div className="d-flex gap-10">
                        <p>S</p>
                        <p>M</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
