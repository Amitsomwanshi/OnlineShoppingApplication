import React from "react";
import "./Wishlist.css";
import Header from "../componants/Header";
import Footer from "../componants/Footer";
import Bradecrum from "../componants/Bradecrum";

export default function Wishlist() {
  return (
    <div>
      <Header />
      <Bradecrum />
      <div className="wishlist-wrapper home-wrapper-2">
        <div className="container-xxl">
            <div className="row">
          <div className="col-3">
            <div className="wishlist-card position-reletive">
              <img src="images/cross.svg" className="cross" alt="" />
              <div className="wishlist-card-image">
                <img src="images/speaker.jpg" className="img-fluid" alt="" />
              </div>
            </div>
            <h5 className="title">
              <b>
                Beoplay A1 Portable Bluetooth <br></br> Speraker With Microphone
              </b>
            </h5>
            <p>$500.00</p>
          </div>
          <div className="col-3">
            <div className="wishlist-card position-reletive">
              <img src="images/cross.svg" className="cross" alt="" />
              <div className="wishlist-card-image">
                <img src="images/honartab3.jpg" className="img-fluid" alt="" />
              </div>
            </div>
            <h5 className="title">
              <b>
              Honor T1 7.0 1 GB RAM 8 GB <br></br> ROM 7  Inch with wi Fi+3g Tablet
              </b>
            </h5>
            <p>$100.00</p>
          </div>
          <div className="col-3">
            <div className="wishlist-card position-reletive">
              <img src="images/cross.svg" className="cross" alt="" />
              <div className="wishlist-card-image">
                <img style={{width:"270px",height:"270px", padding:"35px"}} src="images/watch1.webp" className="img-fluid" alt="" />
              </div>
            </div>
            <h5 className="title">
              <b>
                Milanese Loop Watch Band For <br></br> 42mm/44mm Apple Watch .
              </b>
            </h5>
            <p>$10.00</p>
          </div>
          <div className="col-3">
            <div className="wishlist-card position-reletive">
              <img src="images/cross.svg" className="cross" alt="" />
              <div className="wishlist-card-image">
                <img style={{padding:"25px"}} src="images/baot.webp" className="img-fluid" alt="" />
              </div>
            </div>
          
          <h5 className="title">
            <b>
            boAt Airdopes 381 Wireless in Ear Earphones
            </b>
          </h5>
          <p>$120.00</p>
        </div>
      </div>
      </div>
      </div>
      <Footer />
    </div>
  );
}
