import React from "react";
import "./Signup.css";
import Header from "../../componants/Header";
import Bradecrum from "../../componants/Bradecrum";
import Footer from "../../componants/Footer";

export default function SignupPage() {
  return (
    <div>
      <Header />
      <Bradecrum />
      <div>
        <div className="login-wrapper py-5 home-wrapper">
          <div className="container">
            <div className="row">
              <div className="col-12">
                <div className="login-card">
                  <h3 className="text-center mb-3">
                    <b>Sign Up</b>
                  </h3>
                  <form action="" className="d-flex flex-column gap-15">
                    <div>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Name"
                      />
                    </div>
                    <div>
                      <input
                        type="email"
                        className="form-control"
                        placeholder="Email"
                      />
                    </div>
                    <div>
                      <input
                        type="tel"
                        className="form-control"
                        placeholder="Mobile No"
                      />
                    </div>
                    <div className="mt-1">
                      <input
                        type="password"
                        className="form-control"
                        placeholder="Password"
                      />
                    </div>
                    <div>
                      <div className="d-flex mt-3 justify-content-center gap-15 align-items-center">
                        <button
                          className="button border-0"
                          onClick={() => {
                            alert("Your account has been created...!");
                          }}
                        >
                          Sign Up
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
