import React from "react";

import "./login.css";
import Bradecrum from "../../componants/Bradecrum";
import Header from "../../componants/Header";
import Footer from "../../componants/Footer";
import { Link } from "react-router-dom";

export default function LoginPage() {

  return (
    <div>
      <Header />
      <Bradecrum />
      <div className="login-wrapper py-5 home-wrapper">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="login-card">
                <h3 className="text-center mb-3">
                  <b>Login</b>
                </h3>
                <form action="" className="d-flex flex-column gap-15">
                  <div>
                    <input
                      type="email"
                      className="form-control"
                      placeholder="Email"
                    />
                  </div>
                  <div className="mt-1">
                    <input
                      type="password"
                      className="form-control"
                      placeholder="Password"
                    />
                  </div>
                  <div>
                    <Link to="/forgotPassword" className="forggote">
                      Forgot Password
                    </Link>
                    <div className="d-flex mt-3 justify-content-center gap-15 align-items-center">
                      <button
                        className="button border-0"
                        onClick={() => {
                          alert("You Are Logged In...!");
                        }}
                      >
                        Login
                      </button>
                      <Link to="/signup" className="button signup border-0">
                        Sign Up
                      </Link>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
