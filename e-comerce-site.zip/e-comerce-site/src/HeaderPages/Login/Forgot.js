import React from "react";
import "./Foggote.css";
import Header from "../../componants/Header";
import Bradecrum from "../../componants/Bradecrum";
import Footer from "../../componants/Footer";
import { Link } from "react-router-dom";

export default function ForgotPassword() {
  return (
    <div>
      <Header />
      <Bradecrum />
      <div className="login-wrapper py-5 home-wrapper">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="login-card">
                <h3 className="text-center mb-3">
                  <b>Reset Your Password</b>
                </h3>
                <p className="text-center mt-2 mb-3">
                  we will send you anemail to reset your password
                </p>
                <form action="" className="d-flex flex-column gap-15">
                  <div>
                    <input
                      type="email"
                      className="form-control"
                      placeholder="Email"
                    />
                  </div>

                  <div>
                    <div className="d-flex mt-3 justify-content-center flex-column gap-15 align-items-center">
                      <button
                        className="button border-0"
                        onClick={() => {
                          alert("Send the OTP on your Entered Email");
                        }}
                      >
                        Submit
                      </button>

                      <Link to="/login" className="forggote">
                        Cancle
                      </Link>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
