import React from "react";
import "./BlogCard.css";
import { Link } from "react-router-dom";

export default function BlogCard() {
  return (
    <div>
    <div className="main-div">
    <div className="blog-card">
        <img src="images/blog-1.jpg " className="img-fluid" alt="" />
      </div>

      <div className="blog-content">
        <p className="date">1 dec 2023</p>
        <h5 className="title"><b>A Beutifull Sunday Morning Renaissance</b></h5>
        <p className="desc">

        </p>
        <Link to='/blogs' className="button">Read More</Link>
      </div>
    </div>
    </div>
  );
}
