import React from 'react'
import Header from "../../componants/Header";
import Bradecrum from "../../componants/Bradecrum";
import Footer from "../../componants/Footer";
export default function ShippingPolicy() {
  return (
    <div>
        <Header/>
        <Bradecrum/>
        <div>
            welcome in shiping policy
        </div>
        <Footer/>
      
    </div>
  )
}
