import React from 'react'
import Header from "../../componants/Header";
import Bradecrum from "../../componants/Bradecrum";
import Footer from "../../componants/Footer";
import "./RefundPolicy.css";
export default function RefundPolicy() {
  return (
    <div>
        <Header/>
        <Bradecrum/>
        <div>
            welcome in raefund
        </div>
        <Footer/>
      
    </div>
  )
}
