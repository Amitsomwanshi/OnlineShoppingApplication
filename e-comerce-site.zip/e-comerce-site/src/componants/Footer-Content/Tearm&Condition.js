import React from 'react'
import "./Term&Condition.css";
import Header from "../../componants/Header";
import Bradecrum from "../../componants/Bradecrum";
import Footer from "../../componants/Footer";
export default function TearmCondition() {
  return (
    <div>
        <Header/>
        <Bradecrum/>
        <div>
            welcome in Teram and condition
        </div>
        <Footer/>
      
    </div>
  )
}

