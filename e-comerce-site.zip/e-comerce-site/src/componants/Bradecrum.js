import React from 'react'
import { Link } from 'react-router-dom';
import "./Bradecrum.css";
import Marquee from 'react-fast-marquee';

export default function Bradecrum() {
   
  return (
    <div>
      <div className='bradecrum mb-0 py-4'> 
        <div className='containetr'>
            <div className='row'>
                <div className='col-12'>
                    <p className='text-center mb-0'>
                        <Link to="/" className="click-text">
                          <Marquee>
                             <b>Click Me & Go To Home</b>
                          </Marquee>
                        </Link>
                    </p>
                </div>
            </div>
        </div>
      </div>
    </div>
  )
}
