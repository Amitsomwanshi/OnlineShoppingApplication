import React from "react";
import "./Productcard.css";
import ReactStars from "react-rating-stars-component";


export default function ProductCard() {
  return (
    <div>
      <div className="product-card position-reletive">
        <div className="product-images">
          <img src="images/watch2.webp" alt=""></img>
        </div>
        <div className="product-detail">
          <h6 className="brand">
            <b>Havels</b>
          </h6>
          <h5 className="product-title">
            <b>Kids headphones bulk 10 pck multi colored for students</b>
          </h5>
          <ReactStars count={5} size={24} activeColor="#ffd700" />
          <p className="price">$100.00</p>
        </div>
      </div>
    </div>
  );
}
