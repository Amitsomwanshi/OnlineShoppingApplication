import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./componants/Layout";
import Home from "./pages/Home";
import Contact from "./pages/Contact";
import About from "./pages/About";
import Ourstore from "./pages/Ourstore";
import Blog from "./pages/Blog";
import CompairProduct from "./HeaderPages/CompairProduct";
import Wishlist from "./HeaderPages/Wishlist";
import LoginPage from "./HeaderPages/Login/LoginPage";
import ForgotPassword from "./HeaderPages/Login/Forgot";
import SignupPage from "./HeaderPages/Login/SignupPage";
import SingleBlog from "./pages/SingleBlog";
import PrivacyPolicy from "./componants/Footer-Content/PrivacyPolicy";
import RefundPolicy from "./componants/Footer-Content/RefundPolicy";
import TearmCondition from "./componants/Footer-Content/Tearm&Condition";
import ShippingPolicy from "./componants/Footer-Content/ShippingPolicy";


function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />}></Route>
          <Route path="/layout" element={<Layout />}></Route>
          <Route path="/contact" element={<Contact />}></Route>
          <Route path="/about" element={<About />}></Route>
          <Route path="/ourstore" element={<Ourstore />}></Route>
          <Route path="/blog" element={<Blog />}></Route>
          <Route path="/blogs" element={<SingleBlog/>}></Route>
          <Route path="/compairproduct" element={<CompairProduct />}></Route>
          <Route path="/wishlist" element={<Wishlist />}></Route>
          <Route path="/login" element={<LoginPage />}></Route>
          <Route path="/forgotPassword" element={<ForgotPassword />} />
          <Route path="/signup" element={<SignupPage />} />
          <Route path="/privacy-policy" element={<PrivacyPolicy/>} />
          <Route path="/refund-policy" element={<RefundPolicy/>} />
          <Route path="/tearm-condition" element={<TearmCondition/>} />
          <Route path="/shiping-policy" element={<ShippingPolicy/>} />




        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
