import React from 'react'
import Header from '../componants/Header'
import Footer from '../componants/Footer'

export default function About() {
  return (
    <div>
      <Header/>
      <h1>About</h1>
      <Footer/>
    </div>
  )
}
