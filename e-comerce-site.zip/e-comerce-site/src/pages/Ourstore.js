import React, { useState } from "react";
import Header from "../componants/Header";
import Footer from "../componants/Footer";
import Bradecrum from "../componants/Bradecrum";
import "./Ourstore.css";
import ReactStars from "react-stars";
import ProductCard from "../componants/ProductCard";

export default function Ourstore() {
  const[grid,setGrid]=useState(4);
  alert(grid)
  return (
    <div>
      <Header />
      <div>
        <Bradecrum />

        <div className="store-wrapper home-wrapper-2 py-5">
          <div className="container-xxl">
            <div className="row">
              <div className="col-3">
                <div className="filter-card mb-3">
                  <h3 className="filter-title"> Shop By Categories</h3>
                  <div>
                    <ul className="ps-0">
                      <li>Watch</li>
                      <li>Tv</li>
                      <li>Camera</li>
                      <li>Laptop</li>
                    </ul>
                  </div>
                </div>
                <div className="filter-card mb-3">
                  <h3 className="filter-title">Filter By</h3>
                  <div>
                    <h5 className="sub-title">
                      <b>Availablity</b>{" "}
                    </h5>
                    <div>
                      <div class="form-check">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          value=""
                          id="flexCheckDefault"
                        />
                        <label className="form-check-label" htmlfor="">
                          In Stock {1}
                        </label>
                      </div>

                      <div class="form-check">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          value=""
                          id="flexCheckDefault"
                        />
                        <label className="form-check-label" htmlfor="">
                          Out Of Stock {0}
                        </label>
                      </div>
                    </div>
                    <h5 className="sub-title">
                      <b>Price</b>
                    </h5>
                    <div className="d-flex align-item-center gap-10 ">
                      <div className="form-floating ">
                        <input
                          type="email"
                          className="form-control"
                          id="floatingInput"
                          placeholder="name@example.com"
                        />
                        <label htmlfor="floatingInput">From</label>
                      </div>

                      <div className="form-floating">
                        <input
                          type="email"
                          className="form-control "
                          id="floatingInput"
                          placeholder="name@example.com"
                        />
                        <label htmlfor="floatingInput">To</label>
                      </div>
                    </div>

                    <h5 className="sub-title">
                      <b>Colors</b>
                    </h5>
                    <div>
                      <ul className="colors ps-0">
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                      </ul>
                    </div>

                    <h5 className="sub-title">
                      <b>Size</b>
                    </h5>
                    <div>
                      <div class="form-check">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          value=""
                          id="color-1"
                        />
                        <label className="form-check-label" htmlfor="">
                          S {1}
                        </label>
                      </div>
                      <div class="form-check">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          value=""
                          id="color-2"
                        />
                        <label className="form-check-label" htmlfor="">
                          M {1}
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="filter-card mb-3">
                  <h3 className="filter-title"> Product Tags</h3>
                  <div className="product-tags d-flex flex-wrap align-items-center gap-10">
                    <span className="badge bg-light text-secondary rounded-3 py-2 px-3">
                      . Headphones
                    </span>
                    <span className="badge bg-light text-secondary rounded-3 py-2 px-3">
                      . Laptop
                    </span>
                    <span className="badge bg-light text-secondary rounded-3 py-2 px-3">
                      . Mobile
                    </span>
                    <span className="badge bg-light text-secondary rounded-3 py-2 px-3">
                      . Wire
                    </span>
                  </div>
                </div>
                <div className="filter-card mb-3">
                  <h3 className="filter-title"> Random Products</h3>
                  <div className="random-product mb-3 d-flex">
                    <div className="w-50">
                      <img
                        src="images/watch.jpg"
                        className="img-fluid"
                        alt="watch"
                      />
                    </div>
                    <div className="w-50 ">
                      <h6>
                        <b>
                          Kids Headphones bulk 10 packs multi colored for
                          students
                        </b>
                      </h6>
                      <ReactStars
                        count={5}
                        value={4}
                        size={24}
                        activecolor={"#ffd700"}
                        edit={false}
                      />
                      <p>
                        <b>$300</b>
                      </p>
                    </div>
                  </div>

                  <div className="random-product  d-flex">
                    <div className="w-50">
                      <img
                        src="images/watch.jpg"
                        className="img-fluid"
                        alt="watch"
                      />
                    </div>
                    <div className="w-50 ">
                      <h6>
                        <b>
                          Kids Headphones bulk 10 packs multi colored for
                          students
                        </b>
                      </h6>
                      <ReactStars
                        count={5}
                        value={4}
                        size={24}
                        activecolor={"#ffd700"}
                        edit={false}
                      />
                      <p>
                        <b>$300</b>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-9">
                <div className="filter-sort-grid d-flex mb-4">
                  <div className="d-flex justify-content-end align-item-center">
                    <div className="d-flex  align-items-center gap-10">
                      <p className="mb-0 d-block">Sort By</p>
                      <select name="" className="form-control form-select">
                        <option value="">Featured</option>
                        <option value="best-selling" selected="selected">
                          Best-Selling
                        </option>
                        <option value="title-asscending">
                          Albhabetically, A-Z
                        </option>
                        <option value="title-descending">
                          Alphabetically, Z-A
                        </option>
                        <option value="title-descending">
                          Price, Low to High
                        </option>
                        <option value="title-descending">
                          Price High to Low
                        </option>
                        <option value="title-descending">
                          Date Old to New
                        </option>
                        <option value="title-descending">
                          Date New tO Old
                        </option>
                      </select>
                    </div>

                    <div className="d-flex align-items-center gap-10 justify-content-end">
                      <p className="totalproducts mb-0"> 21 Products</p>
                      <div className=" d-flex gap-10 align-items-center">
                        <img onClick={()=>{setGrid(4)}}
                          src="images/gr4.svg"
                          className=" grid-img d-block img-fluid"
                          alt="grid"
                        />
                        <img onClick={()=>{setGrid(3)}}
                          src="images/gr3.svg"
                          className=" grid-img d-block img-fluid"
                          alt="grid"
                        />
                        <img onClick={()=>{setGrid(2)}}
                          src="images/gr2.svg"
                          className=" grid-img d-block img-fluid"
                          alt="grid"
                        />
                        <img onClick={()=>{setGrid(1)}}
                          src="images/gr.svg"
                          className=" grid-img d-block img-fluid"
                          alt="grid"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="product-list py-5">
                    <div className="d-flex gap-10">
                      <div>
                      <ProductCard grid={grid}/>
                      </div>
                      <div>
                      <ProductCard grid={grid}/>
                      </div>
                      <div>
                      <ProductCard grid={grid}/>
                      </div>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
