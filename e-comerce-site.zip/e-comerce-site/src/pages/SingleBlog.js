import React from 'react'
import "./SingleBlog.css";
import Bradecrum from '../componants/Bradecrum';
import Header from '../componants/Header';
import Footer from '../componants/Footer';
import { Link } from 'react-router-dom';
import {HiArrowLeft} from "react-icons/hi"

export default function SingleBlog() {
  return (
    <div>
       <Header />
        <Bradecrum/>
        <div>
        <div className="blog-wrapper home-wrapper-2 py-5">
        <div className="container-xxl">
          <div className="row">
           
            <div className="col-12">
               <div className='single-blog-card'>
                <Link to="/blog" className='d-flex align-items-center gap-10'> <HiArrowLeft className='fs-4'/> Back To Blogs</Link>
                <h3 className='title'>
                  <b>A Beautiful Sunday Morning Renaissance</b>
                </h3>
                <img src='images/blog-1.jpg' className='img-fluid my-4' alt=''></img>
                <p>
                  You are only as good as your last collection, which is an enourmus pressure. 
                  I think there is something about luxury is is no something people need
                  , but what they want. It raelly pulls at their heart.
                  Ihave a fantastics reletionship with money.
                </p>
               </div>
            </div>
          </div>
        </div>
      </div>
        </div>
        <Footer />
       
      
    </div>
  )
}
